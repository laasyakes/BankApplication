import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-createaccount',
  templateUrl: './dashboard-createaccount.component.html',
  styleUrls: ['./dashboard-createaccount.component.css']
})
export class DashboardCreateaccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
