import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ILoan } from 'src/app/account/models/iloan';
import { LoanService } from 'src/app/loan/services/loan.service';

@Component({
  selector: 'app-loan',
  templateUrl: './loan.component.html',
  styleUrls: ['./loan.component.css']
})
export class LoanComponent implements OnInit {

  constructor(private loanService: LoanService,private router: Router) { }

  loan: ILoan = {
    loanType: '',
    loanAmount: 0,
    loanStatus: '',
    appliedDate: '',
    accountId: ''
  }

  ngOnInit(): void {
  }

  onLoanApplication(): void {

    this.loan.accountId = JSON.parse(localStorage.getItem('accountDetails') || "").accountId;
    this.loanService.createLoan(this.loan).subscribe((res) => {
      localStorage.setItem("loanDetails", JSON.stringify(res));
      this.router.navigate(['/dashboard']);
    },
    (err) => {
      console.log(err);
    })

  }

}
