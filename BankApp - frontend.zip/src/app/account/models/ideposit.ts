export interface IDeposit {
    accountId: string;
    amount: number;
}
