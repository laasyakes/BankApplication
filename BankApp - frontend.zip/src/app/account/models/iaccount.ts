export interface IAccount {
    accountStatus: string;
    accountType: string;
    accountBalance: string;
    pancardNumber: string;
    aadharcardNumber: string;
    createDateTime: string;
    userId: number;
}
