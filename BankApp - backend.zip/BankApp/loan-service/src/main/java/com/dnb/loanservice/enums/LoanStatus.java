package com.dnb.loanservice.enums;

public enum LoanStatus {
	APPROVED,PENDING,DENIED
}
