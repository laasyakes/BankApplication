package com.dnb.accountservice.utils;

public enum LoanStatus {
	APPROVED,PENDING,DENIED
}
