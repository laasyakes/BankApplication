package com.dnb.accountservice.enums;

public enum AccountType {
	
	CURRENT,SAVINGS

}
