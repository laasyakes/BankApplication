package com.dnb.accountservice.utils;

public enum LoanType {
	PERSONAL,HOME,CREDIT

}
